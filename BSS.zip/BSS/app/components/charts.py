import reflex as rx
from app.states.dashboard_state import DashboardState


def chart_container(
    title: str, chart: rx.Component, empty_message: str, data: rx.Var
) -> rx.Component:
    return rx.el.div(
        rx.el.h2(title, class_name="text-lg font-semibold text-[#1C1C1C] mb-4"),
        rx.cond(
            data.length() > 0,
            chart,
            rx.el.div(
                rx.icon("bar_chart_horizontal", class_name="h-12 w-12 text-gray-300"),
                rx.el.p(empty_message, class_name="text-gray-500 mt-4"),
                class_name="flex flex-col items-center justify-center h-[300px] text-center p-4",
            ),
        ),
        class_name="bg-white p-6 rounded-lg border border-gray-200 h-full",
    )


def credit_chart() -> rx.Component:
    return chart_container(
        title="Credit vs Date",
        chart=rx.recharts.line_chart(
            rx.recharts.cartesian_grid(stroke_dasharray="3 3"),
            rx.recharts.x_axis(data_key="date"),
            rx.recharts.y_axis(),
            rx.recharts.tooltip(
                content_style={"background": "white", "border": "1px solid #ccc"}
            ),
            rx.recharts.line(
                data_key="credit", stroke="#22c55e", type_="monotone", dot=False
            ),
            data=DashboardState.credit_vs_date,
            height=300,
        ),
        empty_message="No credit data available to display chart.",
        data=DashboardState.credit_vs_date,
    )


def debit_chart() -> rx.Component:
    return chart_container(
        title="Debit vs Date",
        chart=rx.recharts.line_chart(
            rx.recharts.cartesian_grid(stroke_dasharray="3 3"),
            rx.recharts.x_axis(data_key="date"),
            rx.recharts.y_axis(),
            rx.recharts.tooltip(
                content_style={"background": "white", "border": "1px solid #ccc"}
            ),
            rx.recharts.line(
                data_key="debit", stroke="#ef4444", type_="monotone", dot=False
            ),
            data=DashboardState.debit_vs_date,
            height=300,
        ),
        empty_message="No debit data available to display chart.",
        data=DashboardState.debit_vs_date,
    )


def comparison_chart() -> rx.Component:
    return chart_container(
        title="Total Debit vs. Credit",
        chart=rx.recharts.bar_chart(
            rx.recharts.cartesian_grid(stroke_dasharray="3 3"),
            rx.recharts.x_axis(data_key="name"),
            rx.recharts.y_axis(),
            rx.recharts.tooltip(
                content_style={"background": "white", "border": "1px solid #ccc"}
            ),
            rx.recharts.bar(data_key="debit", fill="#ef4444", name="Total Debit"),
            rx.recharts.bar(data_key="credit", fill="#22c55e", name="Total Credit"),
            data=DashboardState.debit_credit_comparison,
            bar_category_gap="20%",
            height=300,
        ),
        empty_message="No data for comparison.",
        data=DashboardState.debit_credit_comparison,
    )