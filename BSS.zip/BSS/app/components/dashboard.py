import reflex as rx
from app.states.dashboard_state import DashboardState
from app.states.statement_state import Transaction
from app.components.charts import credit_chart, debit_chart, comparison_chart


def summary_card(
    title: str, value: rx.Var, icon: str, color_class: str
) -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.p(title, class_name="text-sm font-medium text-gray-500"),
            rx.icon(tag=icon, class_name=f"h-5 w-5 {color_class}"),
            class_name="flex items-center justify-between",
        ),
        rx.el.p(value.to_string(), class_name="text-2xl font-bold text-[#1C1C1C]"),
        class_name="bg-white p-4 rounded-lg border border-gray-200",
    )


def transaction_table() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.h2(
                "Transactions", class_name="text-xl font-semibold text-[#1C1C1C] mb-2"
            ),
            rx.el.div(
                rx.el.div(
                    rx.icon("search", class_name="h-4 w-4 text-gray-400"),
                    class_name="absolute left-3 top-1/2 -translate-y-1/2",
                ),
                rx.el.input(
                    placeholder="Search transactions...",
                    on_change=DashboardState.set_search_query.debounce(300),
                    class_name="pl-10 w-full bg-white border border-gray-300 rounded-lg py-2 px-4 focus:outline-none focus:ring-2 focus:ring-red-500",
                ),
                class_name="relative w-full max-w-sm",
            ),
            class_name="flex justify-between items-center mb-4",
        ),
        rx.el.div(
            rx.el.table(
                rx.el.thead(
                    rx.el.tr(
                        rx.el.th(
                            "Date",
                            class_name="p-3 text-left font-semibold text-gray-600",
                        ),
                        rx.el.th(
                            "Description",
                            class_name="p-3 text-left font-semibold text-gray-600",
                        ),
                        rx.el.th(
                            "Debit",
                            class_name="p-3 text-right font-semibold text-gray-600",
                        ),
                        rx.el.th(
                            "Credit",
                            class_name="p-3 text-right font-semibold text-gray-600",
                        ),
                        rx.el.th(
                            "Balance",
                            class_name="p-3 text-right font-semibold text-gray-600",
                        ),
                    ),
                    class_name="bg-gray-50",
                ),
                rx.el.tbody(
                    rx.foreach(DashboardState.paginated_transactions, transaction_row)
                ),
                class_name="w-full text-sm table-auto",
            ),
            class_name="rounded-lg border border-gray-200 overflow-x-auto",
        ),
        pagination_controls(),
        class_name="bg-white p-6 rounded-lg border border-gray-200 lg:col-span-3",
    )


def transaction_row(transaction: Transaction) -> rx.Component:
    return rx.el.tr(
        rx.el.td(transaction["date"], class_name="p-3 text-gray-700"),
        rx.el.td(transaction["description"], class_name="p-3 text-gray-700"),
        rx.el.td(
            rx.cond(transaction["debit"] > 0, transaction["debit"].to_string(), "-"),
            class_name="p-3 text-right font-mono text-red-600",
        ),
        rx.el.td(
            rx.cond(transaction["credit"] > 0, transaction["credit"].to_string(), "-"),
            class_name="p-3 text-right font-mono text-green-600",
        ),
        rx.el.td(
            transaction["balance"].to_string(),
            class_name="p-3 text-right font-mono text-gray-800",
        ),
        class_name="border-t border-gray-100 hover:bg-gray-50",
    )


def pagination_controls() -> rx.Component:
    return rx.el.div(
        rx.el.p(
            f"Page {DashboardState.current_page} of {DashboardState.total_pages}",
            class_name="text-sm text-gray-600",
        ),
        rx.el.div(
            rx.el.button(
                "Previous",
                on_click=DashboardState.prev_page,
                disabled=DashboardState.current_page <= 1,
                class_name="px-4 py-2 text-sm font-medium bg-white border border-gray-300 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed",
            ),
            rx.el.button(
                "Next",
                on_click=DashboardState.next_page,
                disabled=DashboardState.current_page >= DashboardState.total_pages,
                class_name="px-4 py-2 text-sm font-medium bg-white border border-gray-300 rounded-lg hover:bg-gray-100 disabled:opacity-50 disabled:cursor-not-allowed ml-2",
            ),
            class_name="flex",
        ),
        class_name="flex items-center justify-between mt-4",
    )


def dashboard() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            summary_card(
                "Total Credit",
                DashboardState.total_credit,
                "arrow_up",
                "text-green-500",
            ),
            summary_card(
                "Total Debit", DashboardState.total_debit, "arrow_down", "text-red-500"
            ),
            summary_card(
                "Final Balance",
                DashboardState.final_balance,
                "landmark",
                "text-blue-500",
            ),
            summary_card(
                "Total Transactions",
                DashboardState.total_transactions.to(str),
                "receipt-text",
                "text-yellow-500",
            ),
            class_name="grid gap-6 md:grid-cols-2 lg:grid-cols-4",
        ),
        rx.el.div(
            credit_chart(), debit_chart(), class_name="grid gap-6 lg:grid-cols-2 mt-6"
        ),
        rx.el.div(comparison_chart(), class_name="mt-6"),
        rx.el.div(transaction_table(), class_name="mt-6"),
    )