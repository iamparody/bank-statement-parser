import reflex as rx
from app.states.ui_state import UIState


def header() -> rx.Component:
    return rx.el.header(
        rx.el.div(
            rx.el.button(
                rx.icon(tag="menu", class_name="h-6 w-6"),
                on_click=UIState.toggle_sidebar,
                class_name="p-2 rounded-md hover:bg-gray-200 md:hidden",
            ),
            rx.el.button(
                rx.icon(
                    rx.cond(
                        UIState.sidebar_collapsed, "panel-right-open", "panel-left-open"
                    ),
                    class_name="h-6 w-6",
                ),
                on_click=UIState.toggle_sidebar,
                class_name="p-2 rounded-md hover:bg-gray-200 hidden md:block",
            ),
            class_name="flex items-center gap-4",
        ),
        rx.el.h1(
            "Bank Statement Analysis", class_name="text-xl font-semibold text-[#1C1C1C]"
        ),
        rx.el.div(class_name="w-10 h-10"),
        class_name="flex items-center justify-between h-16 px-4 border-b bg-white sticky top-0 z-5",
    )