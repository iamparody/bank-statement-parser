import reflex as rx
from app.states.ui_state import UIState
from app.states.statement_state import StatementState


def sidebar_item(text: str, icon: str, url: str) -> rx.Component:
    return rx.el.a(
        rx.icon(tag=icon, class_name="h-5 w-5"),
        rx.cond(
            UIState.sidebar_collapsed, None, rx.el.span(text, class_name="font-medium")
        ),
        href=url,
        class_name="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-500 transition-all hover:text-gray-900 hover:bg-gray-200",
    )


def sidebar_button(text: str, icon: str, on_click: rx.event.EventType) -> rx.Component:
    return rx.el.button(
        rx.icon(tag=icon, class_name="h-5 w-5"),
        rx.cond(
            UIState.sidebar_collapsed, None, rx.el.span(text, class_name="font-medium")
        ),
        on_click=on_click,
        class_name="flex items-center gap-3 rounded-lg px-3 py-2 text-gray-500 transition-all hover:text-gray-900 hover:bg-gray-200 w-full",
    )


def sidebar() -> rx.Component:
    return rx.el.div(
        rx.el.div(
            rx.el.div(
                rx.el.a(
                    rx.icon(tag="landmark", class_name="h-6 w-6 text-red-500"),
                    rx.cond(
                        UIState.sidebar_collapsed,
                        None,
                        rx.el.span(
                            "Bank Analyzer",
                            class_name="text-lg font-bold text-[#1C1C1C]",
                        ),
                    ),
                    href="/",
                    class_name="flex items-center gap-2 font-semibold",
                ),
                class_name="flex h-[60px] items-center justify-center px-6",
            ),
            rx.el.div(
                rx.el.nav(
                    sidebar_item("Dashboard", "layout-dashboard", "/dashboard"),
                    sidebar_item("Upload", "upload", "/"),
                    sidebar_button(
                        "New Analysis", "file-plus-2", StatementState.start_new_analysis
                    ),
                    sidebar_button(
                        "Clear Cache", "trash-2", StatementState.clear_cache
                    ),
                    class_name="flex flex-col items-start px-4 text-sm font-medium",
                ),
                class_name="flex-1 overflow-auto py-2",
            ),
        ),
        class_name=rx.cond(
            UIState.sidebar_collapsed,
            "hidden md:flex flex-col w-20 border-r bg-white h-screen fixed z-10 transition-all",
            "hidden md:flex flex-col w-64 border-r bg-white h-screen fixed z-10 transition-all",
        ),
    )