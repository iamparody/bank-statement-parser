import reflex as rx
import pdfplumber
import re
from dateutil import parser as date_parser
import pandas as pd
from typing import TypedDict
import logging
from pdf2image import convert_from_path
import pytesseract

logging.basicConfig(level=logging.INFO)


class Transaction(TypedDict):
    date: str
    description: str
    debit: float
    credit: float
    balance: float


class StatementState(rx.State):
    transactions: list[Transaction] = []
    is_loading: bool = False
    error_message: str = ""
    current_analysis_id: str = ""

    def _parse_amount(self, amount_str: str | None) -> float:
        if not amount_str:
            return 0.0
        cleaned_str = amount_str.replace(",", "").strip()
        if not cleaned_str:
            return 0.0
        try:
            return float(cleaned_str)
        except (ValueError, TypeError) as e:
            logging.exception(f"Error parsing amount: {e}")
            return 0.0

    def _parse_transactions_from_text(self, text: str) -> list[Transaction]:
        transactions = []
        pattern1 = re.compile(
            "^(\\d{2}/\\d{2}/\\d{4})\\s+(.+?)\\s+([\\d,.]+\\.\\d{2})\\s+([\\d,.]+\\.\\d{2})\\s+([\\d,.]+\\.\\d{2})$",
            re.MULTILINE,
        )
        pattern2 = re.compile(
            "^(\\d{2}/\\d{2})\\s+(.+?)\\s+([\\d,.]+\\.\\d{2})$", re.MULTILINE
        )
        lines = text.split("""
""")
        for line in lines:
            match = pattern1.match(line.strip())
            if match:
                date_str, desc, debit_str, credit_str, balance_str = match.groups()
                try:
                    transactions.append(
                        {
                            "date": date_parser.parse(date_str, dayfirst=True).strftime(
                                "%Y-%m-%d"
                            ),
                            "description": desc.strip(),
                            "debit": self._parse_amount(debit_str),
                            "credit": self._parse_amount(credit_str),
                            "balance": self._parse_amount(balance_str),
                        }
                    )
                except (date_parser.ParserError, ValueError) as e:
                    logging.exception(
                        f"Error parsing transaction line with pattern1: {e}"
                    )
                    continue
        if not transactions:
            current_balance = 0.0
            summary_section = re.search(
                "Beginning balance on .*? \\$([\\d,.]+\\.\\d{2})", text
            )
            if summary_section:
                current_balance = self._parse_amount(summary_section.group(1))
            for line in lines:
                match = pattern2.match(line.strip())
                if match:
                    date_str, desc, amount_str = match.groups()
                    amount = self._parse_amount(amount_str)
                    debit, credit = (0, 0)
                    if "debit" in desc.lower() or "withdrawal" in desc.lower():
                        debit = amount
                        current_balance -= amount
                    else:
                        credit = amount
                        current_balance += amount
                    try:
                        transactions.append(
                            {
                                "date": date_parser.parse(
                                    date_str, default=pd.to_datetime("today")
                                ).strftime("%Y-%m-%d"),
                                "description": desc.strip(),
                                "debit": debit,
                                "credit": credit,
                                "balance": current_balance,
                            }
                        )
                    except (date_parser.ParserError, ValueError) as e:
                        logging.exception(
                            f"Error parsing transaction line with pattern2: {e}"
                        )
                        continue
        return transactions

    def _parse_transactions(self, file_path: str, file: rx.UploadFile):
        extracted_transactions = []
        all_text = ""
        try:
            with pdfplumber.open(file_path) as pdf:
                logging.info(f"Processing {file.name} with pdfplumber.")
                for i, page in enumerate(pdf.pages):
                    page_text = page.extract_text() or ""
                    all_text += (
                        page_text
                        + """
"""
                    )
                    tables = page.extract_tables(
                        table_settings={
                            "vertical_strategy": "lines",
                            "horizontal_strategy": "text",
                            "snap_tolerance": 4,
                        }
                    )
                    if tables:
                        for table in tables:
                            for row in table[1:]:
                                if not row or len(row) < 6:
                                    continue
                                (
                                    date_cell,
                                    desc_cell,
                                    debit_cell,
                                    credit_cell,
                                    balance_cell,
                                ) = (row[0], row[2], row[3], row[4], row[5])
                                if not date_cell or not desc_cell:
                                    continue
                                date_lines = date_cell.split("""
""")
                                desc_lines = desc_cell.split("""
""")
                                debit_lines = (debit_cell or "").split("""
""")
                                credit_lines = (credit_cell or "").split("""
""")
                                balance_lines = (balance_cell or "").split("""
""")
                                max_lines = max(len(date_lines), len(desc_lines))
                                for i in range(max_lines):
                                    try:
                                        date_str = (
                                            date_lines[i]
                                            if i < len(date_lines)
                                            and date_lines[i].strip()
                                            else date_lines[0]
                                            if date_lines
                                            else None
                                        )
                                        if not date_str or len(date_str.strip()) < 8:
                                            continue
                                        desc = (
                                            desc_lines[i] if i < len(desc_lines) else ""
                                        )
                                        debit = self._parse_amount(
                                            debit_lines[i]
                                            if i < len(debit_lines)
                                            else None
                                        )
                                        credit = self._parse_amount(
                                            credit_lines[i]
                                            if i < len(credit_lines)
                                            else None
                                        )
                                        balance = self._parse_amount(
                                            balance_lines[i]
                                            if i < len(balance_lines)
                                            else None
                                        )
                                        if debit == 0 and credit == 0:
                                            continue
                                        parsed_date = date_parser.parse(
                                            date_str, dayfirst=True
                                        ).strftime("%Y-%m-%d")
                                        extracted_transactions.append(
                                            {
                                                "date": parsed_date,
                                                "description": desc.strip(),
                                                "debit": debit,
                                                "credit": credit,
                                                "balance": balance,
                                            }
                                        )
                                    except (
                                        date_parser.ParserError,
                                        ValueError,
                                        IndexError,
                                    ) as e:
                                        logging.exception(
                                            f"Error parsing transaction row from table: {e}"
                                        )
                                        continue
            if not extracted_transactions:
                if not all_text.strip():
                    logging.info(f"{file.name} has no text, attempting OCR.")
                    try:
                        images = convert_from_path(file_path)
                        ocr_text = ""
                        for image in images:
                            ocr_text += pytesseract.image_to_string(image)
                        all_text = ocr_text
                        if not all_text.strip():
                            self.error_message = f"OCR failed on {file.name}. No text could be extracted."
                            logging.error(self.error_message)
                            return []
                    except Exception as e:
                        self.error_message = (
                            f"OCR processing failed for {file.name}: {e}"
                        )
                        logging.exception(self.error_message)
                        return []
                logging.info(
                    f"No table-based transactions found in {file.name}. Attempting text-based parsing."
                )
                text_transactions = self._parse_transactions_from_text(all_text)
                if text_transactions:
                    logging.info(
                        f"Found {len(text_transactions)} transactions via text parsing in {file.name}"
                    )
                    extracted_transactions.extend(text_transactions)
            if not extracted_transactions:
                logging.warning(f"Could not extract any transactions from {file.name}")
            return extracted_transactions
        except Exception as e:
            logging.exception(f"Error processing PDF file {file.name}: {e}")
            self.error_message = (
                f"An unexpected error occurred while processing {file.name}."
            )
            return []

    @rx.event
    def start_new_analysis(self):
        """Clears transactions and prepares for a new analysis."""
        self.transactions.clear()
        self.current_analysis_id = ""
        yield rx.clear_selected_files("upload_area")
        return rx.redirect("/")

    @rx.event
    def clear_cache(self):
        """Resets the entire application state."""
        self.reset()
        yield rx.toast.info("Cache cleared. Start a new analysis.")
        yield rx.clear_selected_files("upload_area")
        yield rx.redirect("/")

    @rx.event
    async def handle_upload(self, files: list[rx.UploadFile]):
        self.is_loading = True
        self.error_message = ""
        yield
        all_transactions = []
        for file in files:
            upload_data = await file.read()
            file_path = rx.get_upload_dir() / file.name
            with file_path.open("wb") as f:
                f.write(upload_data)
            parsed_tx = self._parse_transactions(file_path, file)
            if parsed_tx:
                all_transactions.extend(parsed_tx)
            elif self.error_message:
                yield rx.toast.error(self.error_message)
                self.error_message = ""
            else:
                generic_error = f"Could not extract transactions from {file.name}. Format might be unsupported."
                yield rx.toast.error(generic_error)
        if all_transactions:
            combined_transactions = self.transactions + all_transactions
            df = pd.DataFrame(combined_transactions)
            df.drop_duplicates(inplace=True)
            df["date"] = pd.to_datetime(df["date"])
            df = df.sort_values(by="date", kind="mergesort").reset_index(drop=True)
            if not df.empty:
                first_row = df.iloc[0]
                initial_balance = (
                    first_row["balance"] - first_row["credit"] + first_row["debit"]
                )
                df.loc[0, "balance"] = (
                    initial_balance + df.loc[0, "credit"] - df.loc[0, "debit"]
                )
                for i in range(1, len(df)):
                    prev_balance = df.loc[i - 1, "balance"]
                    df.loc[i, "balance"] = (
                        prev_balance + df.loc[i, "credit"] - df.loc[i, "debit"]
                    )
            df["date"] = df["date"].dt.strftime("%Y-%m-%d")
            self.transactions = df.to_dict("records")
        self.is_loading = False
        if self.transactions:
            yield rx.toast.success(
                f"Successfully parsed and merged {len(all_transactions)} new transactions! Total: {len(self.transactions)}"
            )
            yield rx.redirect("/dashboard")
        elif not self.error_message and (not all_transactions):
            yield rx.toast.info("No new transactions were found in the uploaded files.")
        yield rx.clear_selected_files("upload_area")