import reflex as rx
from app.states.statement_state import StatementState, Transaction
import pandas as pd


class DashboardState(rx.State):
    transactions: list[Transaction] = []
    current_page: int = 1
    items_per_page: int = 10
    search_query: str = ""

    @rx.event
    async def load_transactions(self):
        statement_state = await self.get_state(StatementState)
        self.transactions = statement_state.transactions

    @rx.var
    def filtered_transactions(self) -> list[Transaction]:
        if not self.search_query:
            return self.transactions
        return [
            t
            for t in self.transactions
            if self.search_query.lower() in t["description"].lower()
        ]

    @rx.var
    def total_transactions(self) -> int:
        return len(self.filtered_transactions)

    @rx.var
    def total_debit(self) -> float:
        return sum((t["debit"] for t in self.transactions))

    @rx.var
    def total_credit(self) -> float:
        return sum((t["credit"] for t in self.transactions))

    @rx.var
    def final_balance(self) -> float:
        if not self.transactions:
            return 0.0
        return self.transactions[-1]["balance"]

    @rx.var
    def paginated_transactions(self) -> list[Transaction]:
        start_index = (self.current_page - 1) * self.items_per_page
        end_index = start_index + self.items_per_page
        return self.filtered_transactions[start_index:end_index]

    @rx.var
    def total_pages(self) -> int:
        if not self.filtered_transactions:
            return 1
        return -(-len(self.filtered_transactions) // self.items_per_page)

    @rx.event
    def next_page(self):
        if self.current_page < self.total_pages:
            self.current_page += 1

    @rx.event
    def prev_page(self):
        if self.current_page > 1:
            self.current_page -= 1

    @rx.var
    def credit_vs_date(self) -> list[dict]:
        if not self.transactions:
            return []
        df = pd.DataFrame(self.transactions)
        df["date"] = pd.to_datetime(df["date"])
        df = df[df["credit"] > 0]
        credit_data = df.groupby("date")["credit"].sum().reset_index()
        return credit_data.to_dict("records")

    @rx.var
    def debit_vs_date(self) -> list[dict]:
        if not self.transactions:
            return []
        df = pd.DataFrame(self.transactions)
        df["date"] = pd.to_datetime(df["date"])
        df = df[df["debit"] > 0]
        debit_data = df.groupby("date")["debit"].sum().reset_index()
        return debit_data.to_dict("records")

    @rx.var
    def debit_credit_comparison(self) -> list[dict]:
        return [
            {
                "name": "Total Debit vs Credit",
                "debit": self.total_debit,
                "credit": self.total_credit,
            }
        ]