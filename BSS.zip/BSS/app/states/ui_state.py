import reflex as rx


class UIState(rx.State):
    """Manages the UI state of the application."""

    sidebar_collapsed: bool = False

    @rx.event
    def toggle_sidebar(self):
        """Toggles the collapsed state of the sidebar."""
        self.sidebar_collapsed = not self.sidebar_collapsed