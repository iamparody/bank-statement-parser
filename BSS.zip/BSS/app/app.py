import reflex as rx
from app.states.statement_state import StatementState
from app.states.dashboard_state import DashboardState
from app.states.ui_state import UIState
from app.components.sidebar import sidebar
from app.components.header import header


def main_layout(child: rx.Component) -> rx.Component:
    """A layout that includes the sidebar and header."""
    return rx.el.div(
        sidebar(),
        rx.el.div(
            header(),
            rx.el.main(child, class_name="p-4 md:p-6 lg:p-8"),
            class_name=rx.cond(
                UIState.sidebar_collapsed,
                "transition-all ml-0",
                "transition-all ml-0 md:ml-64",
            ),
        ),
        class_name="font-['Inter'] bg-[#F7F7F7] min-h-screen",
    )


def index() -> rx.Component:
    return main_layout(
        rx.el.div(
            rx.el.div(
                rx.el.h1(
                    "Bank Statement Analyzer",
                    class_name="text-2xl font-bold text-[#1C1C1C]",
                ),
                rx.el.p(
                    "Upload bank statements for the same person to start.",
                    class_name="text-sm text-gray-600",
                ),
                class_name="mb-6 text-center",
            ),
            rx.upload.root(
                rx.el.div(
                    rx.icon(tag="cloud_upload", class_name="w-12 h-12 text-gray-400"),
                    rx.el.p(
                        "Drag & drop files here, or click to select files",
                        class_name="text-gray-600 mt-2",
                    ),
                    class_name="flex flex-col items-center justify-center p-8 border-2 border-dashed border-gray-300 rounded-lg cursor-pointer hover:bg-gray-50 transition-colors",
                ),
                id="upload_area",
                accept={"application/pdf": [".pdf"]},
                multiple=True,
                class_name="w-full max-w-lg mb-4",
            ),
            rx.el.div(
                rx.foreach(
                    rx.selected_files("upload_area"),
                    lambda file: rx.el.div(
                        rx.icon("file-text", class_name="h-4 w-4 mr-2"),
                        file,
                        class_name="flex items-center text-sm p-2 bg-gray-100 rounded-md",
                    ),
                ),
                class_name="space-y-2 w-full max-w-lg mb-4",
            ),
            rx.el.button(
                rx.cond(
                    StatementState.is_loading,
                    rx.el.span("Analyzing...", className="animate-pulse"),
                    rx.el.span("Analyze Statements"),
                ),
                on_click=StatementState.handle_upload(
                    rx.upload_files(upload_id="upload_area")
                ),
                disabled=StatementState.is_loading,
                class_name="bg-red-500 text-white px-6 py-2 rounded-lg hover:bg-red-600 transition-colors flex items-center font-medium disabled:opacity-50",
            ),
            class_name="flex flex-col items-center justify-center w-full",
        )
    )


app = rx.App(
    theme=rx.theme(appearance="light"),
    head_components=[
        rx.el.link(rel="preconnect", href="https://fonts.googleapis.com"),
        rx.el.link(rel="preconnect", href="https://fonts.gstatic.com", cross_origin=""),
        rx.el.link(
            href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700&display=swap",
            rel="stylesheet",
        ),
    ],
)
from app.components.dashboard import dashboard


def dashboard_page() -> rx.Component:
    return main_layout(dashboard())


app.add_page(index, route="/")
app.add_page(
    dashboard_page, route="/dashboard", on_load=DashboardState.load_transactions
)